/*
 * invert.c
 *
 * Portable C version of cartridge image
 * bank inverter
 *
 * This program does not invert individual bits. It pads the input
 * to an 8 KiB boundary using 0x00 bytes, then reverses the order of
 * the 8 KiB banks.
 *
 * Usage:
 *     invert file1.bin [file2.bin ...]
 *
 * Each output is written in the current working directory using
 * the input basename plus "_i" before the extension:
 *
 *     game9.bin  ->  game9_i.bin
 */

#ifdef _MSC_VER
#define _CRT_SECURE_NO_WARNINGS
#endif

#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define BANK_SIZE 8192u
#define PAD_BYTE  0x00u

static const char *path_basename(const char *path)
{
    const char *slash = strrchr(path, '/');
    const char *backslash = strrchr(path, '\\');
    const char *base = path;

    if (slash != NULL && slash + 1 > base) {
        base = slash + 1;
    }
    if (backslash != NULL && backslash + 1 > base) {
        base = backslash + 1;
    }

    return base;
}

static char *make_output_name(const char *input_path)
{
    const char *base = path_basename(input_path);
    const char *dot = strrchr(base, '.');
    size_t base_len = strlen(base);
    size_t stem_len;
    size_t ext_len;
    char *output;

    /*
     * splitext behavior for ordinary filenames:
     * a leading dot alone does not begin an extension.
     */
    if (dot != NULL && dot != base) {
        stem_len = (size_t)(dot - base);
        ext_len = base_len - stem_len;
    } else {
        stem_len = base_len;
        ext_len = 0;
        dot = base + base_len;
    }

    if (stem_len > SIZE_MAX - ext_len - 3u) {
        return NULL;
    }

    output = (char *)malloc(stem_len + 2u + ext_len + 1u);
    if (output == NULL) {
        return NULL;
    }

    memcpy(output, base, stem_len);
    memcpy(output + stem_len, "_i", 2u);
    memcpy(output + stem_len + 2u, dot, ext_len);
    output[stem_len + 2u + ext_len] = '\0';

    return output;
}

static int process_file(const char *input_path)
{
    FILE *input = NULL;
    FILE *output = NULL;
    unsigned char *data = NULL;
    char *output_name = NULL;
    long file_length;
    size_t input_size;
    size_t padding;
    size_t padded_size;
    size_t bank_count;
    size_t bank;
    int result = EXIT_FAILURE;

    input = fopen(input_path, "rb");
    if (input == NULL) {
        fprintf(stderr, "Error opening \"%s\": %s; skipping\n",
                input_path, strerror(errno));
        goto cleanup;
    }

    if (fseek(input, 0, SEEK_END) != 0) {
        fprintf(stderr, "Error seeking in \"%s\": %s; skipping\n",
                input_path, strerror(errno));
        goto cleanup;
    }

    file_length = ftell(input);
    if (file_length < 0) {
        fprintf(stderr, "Error determining length of \"%s\": %s; skipping\n",
                input_path, strerror(errno));
        goto cleanup;
    }

    if (fseek(input, 0, SEEK_SET) != 0) {
        fprintf(stderr, "Error rewinding \"%s\": %s; skipping\n",
                input_path, strerror(errno));
        goto cleanup;
    }

    input_size = (size_t)file_length;
    printf("Length of input file in bytes: %zu\n", input_size);

    padding = (BANK_SIZE - (input_size % BANK_SIZE)) % BANK_SIZE;

    if (input_size > SIZE_MAX - padding) {
        fprintf(stderr, "Error: \"%s\" is too large; skipping\n", input_path);
        goto cleanup;
    }

    padded_size = input_size + padding;

    /*
     * malloc(0) is implementation-defined, so allocate one byte for
     * an empty input even though no data will be read or written.
     */
    data = (unsigned char *)malloc(padded_size == 0 ? 1u : padded_size);
    if (data == NULL) {
        fprintf(stderr, "Error allocating memory for \"%s\"; skipping\n",
                input_path);
        goto cleanup;
    }

    if (input_size > 0 &&
        fread(data, 1u, input_size, input) != input_size) {
        fprintf(stderr, "Error reading \"%s\": %s; skipping\n",
                input_path, ferror(input) ? strerror(errno) : "unexpected end of file");
        goto cleanup;
    }

    if (padding > 0) {
        memset(data + input_size, PAD_BYTE, padding);
    }

    output_name = make_output_name(input_path);
    if (output_name == NULL) {
        fprintf(stderr, "Error creating output filename for \"%s\"; skipping\n",
                input_path);
        goto cleanup;
    }

    output = fopen(output_name, "wb");
    if (output == NULL) {
        fprintf(stderr, "Error opening \"%s\": %s; skipping\n",
                output_name, strerror(errno));
        goto cleanup;
    }

    bank_count = padded_size / BANK_SIZE;

    for (bank = bank_count; bank > 0; --bank) {
        const unsigned char *bank_data = data + ((bank - 1u) * BANK_SIZE);

        if (fwrite(bank_data, 1u, BANK_SIZE, output) != BANK_SIZE) {
            fprintf(stderr, "Error writing \"%s\": %s; skipping\n",
                    output_name, strerror(errno));
            goto cleanup;
        }
    }

    if (fclose(output) != 0) {
        output = NULL;
        fprintf(stderr, "Error closing \"%s\": %s\n",
                output_name, strerror(errno));
        goto cleanup;
    }
    output = NULL;

    printf("Wrote: %s\n", output_name);
    result = EXIT_SUCCESS;

cleanup:
    if (output != NULL) {
        fclose(output);
    }
    if (input != NULL) {
        fclose(input);
    }
    free(data);
    free(output_name);

    return result;
}

int main(int argc, char *argv[])
{
    int i;
    int overall_result = EXIT_SUCCESS;

    if (argc < 2) {
        printf(
            "\n"
            "TI-99/4A Cartridge Bank Inverter v1.0\n"
            "=====================================\n"
            "Reverses the order of 8 KiB banks in TI cartridge image files\n"
            "for use with 74LS378- and 74LS379-based cartridge boards.\n"
            "\n"
            "For files sized to an 8 KiB multiple, running the output through\n"
            "the program again restores the original bank order.\n"
            "\n"
            "Example:\n"
            "  filename.bin  ->  filename_i.bin\n"
            "\n"
            "For files sized to an 8 KiB multiple, processing the output\n"
            "again restores the original data and bank order. Output files\n"
            "always receive another \"_i\" before the extension.\n"
            "\n"
            "Credits:\n"
            "  acadiel, Tursi, Ksarul, ralphb, and the AtariAge community\n"
            "  Original utility circa 2016\n"
            "\n"
            "Usage:\n"
            "  %s <file> [file ...]\n"
            "\n",
            argv[0]
        );

        return EXIT_SUCCESS;
    }

    for (i = 1; i < argc; ++i) {
        if (process_file(argv[i]) != EXIT_SUCCESS) {
            overall_result = EXIT_FAILURE;
        }
    }

    return overall_result;
}